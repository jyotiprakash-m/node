const express = require('express');

const app = express();

app.set('view engine','ejs')

app.use(express.urlencoded({extended:false}))


app.get("/",(req,res) =>{
    // res.send("hello world")
    res.render('./baseproject/index.ejs')
})
app.get("/automotiveCar",(req,res) =>{
    // res.send("hello world")
    res.render('./automotiveCarDesign/index.ejs')
})
app.get("/restaurantFood",(req,res) =>{
    // res.send("hello world")
    res.render('./restaurantFoodDesign/index.ejs')
})
app.get("/footwear",(req,res) =>{
    // res.send("hello world")
    res.render('./footwearDesign/index.ejs')
})
app.get("/fashion",(req,res) =>{
    // res.send("hello world")
    res.render('./fashionDesign/index.ejs')
})
app.get("/newsPaper",(req,res) =>{
    // res.send("hello world")
    res.render('./newsPaperDesign/index.ejs')
})
app.get("/streaming",(req,res) =>{
    // res.send("hello world")
    res.render('./streamingDesign/index.ejs')
})
app.get("/technologyIt",(req,res) =>{
    // res.send("hello world")
    res.render('./technologyItDesign/index.ejs')
})

app.listen(3030,()=>{
    console.log("Site is running on 3030")
})